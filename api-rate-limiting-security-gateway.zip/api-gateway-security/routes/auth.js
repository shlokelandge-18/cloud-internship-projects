const express = require('express');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const router = express.Router();

// Mock user store — in a real deployment this would be Cognito / Azure AD / a users table.
const USERS = [
  { username: 'admin', password: 'admin123', role: 'admin' },
  { username: 'alice', password: 'alice123', role: 'user' },
];

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = USERS.find((u) => u.username === username && u.password === password);

  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  const token = jwt.sign(
    { username: user.username, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: '1h' }
  );

  res.json({ token, expiresIn: '1h', role: user.role });
});

module.exports = router;
