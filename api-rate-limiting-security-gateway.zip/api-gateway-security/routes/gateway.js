const express = require('express');
const router = express.Router();

// These represent "downstream microservices" the gateway is protecting.
// In a real system these would be separate services behind API Gateway / ALB.

router.get('/orders', (req, res) => {
  res.json({
    service: 'orders-service',
    user: req.user.username,
    role: req.user.role,
    data: [
      { orderId: 101, item: 'Wireless Mouse', status: 'Shipped' },
      { orderId: 102, item: 'Mechanical Keyboard', status: 'Processing' },
    ],
  });
});

router.get('/users', (req, res) => {
  res.json({
    service: 'users-service',
    user: req.user.username,
    role: req.user.role,
    data: [
      { username: 'admin', role: 'admin' },
      { username: 'alice', role: 'user' },
    ],
  });
});

router.get('/reports', (req, res) => {
  res.json({
    service: 'reports-service',
    user: req.user.username,
    role: req.user.role,
    data: { totalOrders: 2, totalUsers: 2, generatedAt: new Date().toISOString() },
  });
});

module.exports = router;
