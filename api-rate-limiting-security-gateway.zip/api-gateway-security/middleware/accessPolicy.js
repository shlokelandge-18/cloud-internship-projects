const policies = require('../policies.json');

/**
 * Enforces per-role access policies loaded from policies.json.
 * Blocks a request if the caller's role isn't allowed to hit this route.
 */
function enforceAccessPolicy(req, res, next) {
  const role = req.user?.role;
  const policy = policies[role];

  if (!policy) {
    return res.status(403).json({ error: `No access policy defined for role '${role}'.` });
  }

  const routeAllowed = policy.allowedRoutes.some((allowed) => req.path.startsWith(allowed));
  if (!routeAllowed) {
    return res.status(403).json({ error: `Role '${role}' is not permitted to access ${req.path}.` });
  }

  next();
}

module.exports = { enforceAccessPolicy };
