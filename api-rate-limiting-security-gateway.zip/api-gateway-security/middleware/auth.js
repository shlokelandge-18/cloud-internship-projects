const jwt = require('jsonwebtoken');
require('dotenv').config();

/**
 * Verifies a Bearer token issued by /auth/login.
 * Attaches decoded { username, role } to req.user on success.
 */
function authenticateToken(req, res, next) {
  const header = req.headers['authorization'];
  const token = header && header.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token.' });
    }
    req.user = decoded;
    next();
  });
}

module.exports = { authenticateToken };
