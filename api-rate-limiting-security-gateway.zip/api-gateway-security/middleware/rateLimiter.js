const rateLimit = require('express-rate-limit');
const policies = require('../policies.json');
require('dotenv').config();

const windowMs = Number(process.env.RATE_LIMIT_WINDOW_MS) || 60000;
const baseMax = Number(process.env.RATE_LIMIT_MAX_REQUESTS) || 10;

/**
 * Rate limit keyed by authenticated user, with a per-role multiplier
 * pulled from policies.json (e.g. admins get 3x the base allowance).
 */
const dynamicRateLimiter = rateLimit({
  windowMs,
  max: (req) => {
    const role = req.user?.role || 'user';
    const multiplier = policies[role]?.rateLimitMultiplier || 1;
    return baseMax * multiplier;
  },
  keyGenerator: (req) => req.user?.username || req.ip,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Rate limit exceeded. Please slow down and try again shortly.' },
});

module.exports = { dynamicRateLimiter };
