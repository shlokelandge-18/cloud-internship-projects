/**
 * Sends an SMS notification.
 * Simulated by default (prints to console) so the project needs no paid
 * SMS provider account. To go live, plug in Twilio / SNS here:
 *
 *   const client = require('twilio')(accountSid, authToken);
 *   await client.messages.create({ to, from, body });
 */
async function sendSms({ to, body }) {
  console.log(`[SMS - SIMULATED] To: ${to} | Message: ${body}`);
  return { success: true, simulated: true };
}

module.exports = { sendSms };
