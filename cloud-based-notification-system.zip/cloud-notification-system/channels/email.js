const nodemailer = require('nodemailer');

/**
 * Sends an email notification.
 * If SMTP credentials are set in the environment, it sends a real email.
 * Otherwise it falls back to logging the message (so the project runs
 * out-of-the-box with zero external accounts needed).
 */
async function sendEmail({ to, subject, body }) {
  const hasSmtpConfig = process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS;

  if (!hasSmtpConfig) {
    console.log(`[EMAIL - SIMULATED] To: ${to} | Subject: ${subject} | Body: ${body}`);
    return { success: true, simulated: true };
  }

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT) || 587,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });

  await transporter.sendMail({
    from: process.env.SMTP_USER,
    to,
    subject,
    text: body,
  });

  return { success: true, simulated: false };
}

module.exports = { sendEmail };
