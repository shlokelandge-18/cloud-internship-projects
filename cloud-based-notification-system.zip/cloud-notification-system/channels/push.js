/**
 * Sends a push notification.
 * Simulated by default. To go live, plug in Firebase Cloud Messaging:
 *
 *   const admin = require('firebase-admin');
 *   await admin.messaging().send({ token, notification: { title, body } });
 */
async function sendPush({ deviceToken, title, body }) {
  console.log(`[PUSH - SIMULATED] Device: ${deviceToken} | Title: ${title} | Body: ${body}`);
  return { success: true, simulated: true };
}

module.exports = { sendPush };
