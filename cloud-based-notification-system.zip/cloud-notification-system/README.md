# Cloud-Based Notification System

An event-driven, multi-channel notification system built in Node.js. It simulates a serverless notification pipeline (Email + SMS + Push) with queue-based processing and delivery tracking — runnable entirely on your machine, no cloud account required.

## Architecture

```
Producer (index.js)
      │  enqueue(notification)
      ▼
NotificationQueue (EventEmitter — simulates SQS/SNS)
      │  emits 'message'
      ▼
Worker (worker.js)  ── simulates a Lambda triggered by the queue
      │
      ├──► Email channel  (nodemailer, falls back to console log)
      ├──► SMS channel    (simulated — plug in Twilio/SNS to go live)
      └──► Push channel   (simulated — plug in Firebase Cloud Messaging to go live)
      │
      ▼
Delivery Tracker (tracker.js) → data/delivery-log.json  (simulates a DynamoDB delivery-status table)
```

This models the same event-driven, decoupled design as a real cloud notification service: a producer publishes an event, a queue buffers it, and a worker (Lambda-equivalent) fans it out across channels while independently tracking delivery status.

## Running locally

```bash
npm install
npm start
```

This runs `index.js`, which fires three sample events (order confirmation, password reset, promotional offer) across different channel combinations, then prints the resulting delivery log from `data/delivery-log.json`.

## Going live (optional)

By default, email/SMS/push are all **simulated** (logged to console) so the project works with zero external accounts. To send real email:

1. Copy `.env.example` to `.env`
2. Fill in SMTP credentials (e.g. a Gmail App Password)
3. Re-run `npm start` — emails will now actually send; SMS/push remain simulated unless you wire in Twilio/FCM (stub functions are marked in `channels/sms.js` and `channels/push.js`)

## Mapping to real cloud services

| This project              | Real cloud equivalent                  |
|----------------------------|------------------------------------------|
| `NotificationQueue`         | AWS SQS / SNS topic                     |
| `worker.js`                 | AWS Lambda triggered by queue event     |
| `channels/email.js`         | SES / SMTP relay                        |
| `channels/sms.js`           | AWS SNS SMS / Twilio                    |
| `channels/push.js`          | Firebase Cloud Messaging                |
| `data/delivery-log.json`    | DynamoDB delivery-status table          |

## Tech stack
Node.js, EventEmitter (queue simulation), nodemailer, uuid
