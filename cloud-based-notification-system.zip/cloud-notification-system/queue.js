const EventEmitter = require('events');

/**
 * NotificationQueue simulates a message queue (like AWS SQS / a Pub-Sub topic).
 * Producers call enqueue(); the queue emits 'message' events that workers
 * subscribe to, decoupling notification producers from delivery channels —
 * the same event-driven pattern a serverless notification pipeline uses.
 */
class NotificationQueue extends EventEmitter {
  constructor() {
    super();
    this.queue = [];
  }

  enqueue(notification) {
    this.queue.push(notification);
    // Simulate async queue processing (like a Lambda triggered by SQS)
    setImmediate(() => this._processNext());
  }

  _processNext() {
    if (this.queue.length === 0) return;
    const notification = this.queue.shift();
    this.emit('message', notification);
  }
}

module.exports = new NotificationQueue();
