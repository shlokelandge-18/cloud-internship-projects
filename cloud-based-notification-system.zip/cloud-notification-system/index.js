const queue = require('./worker'); // starts the worker (subscribes to queue)
const { getDeliveryLog } = require('./tracker');

/**
 * Demo: simulates three real-world events that trigger notifications
 * across different channels, then prints the delivery log.
 */
function demo() {
  console.log('--- Cloud-Based Notification System: Demo ---\n');

  queue.enqueue({
    event: 'ORDER_CONFIRMED',
    channels: ['email', 'sms'],
    recipient: { email: 'customer1@example.com', phone: '+911234567890' },
    subject: 'Your order has been confirmed',
    body: 'Order #101 has been confirmed and will ship within 2 days.',
  });

  queue.enqueue({
    event: 'PASSWORD_RESET',
    channels: ['email'],
    recipient: { email: 'customer2@example.com' },
    subject: 'Password reset requested',
    body: 'Click the link to reset your password. This link expires in 15 minutes.',
  });

  queue.enqueue({
    event: 'PROMOTIONAL_OFFER',
    channels: ['push', 'sms'],
    recipient: { deviceToken: 'device-abc-123', phone: '+919876543210' },
    subject: 'Flash Sale!',
    body: '50% off on all electronics today only.',
  });

  // Give the async queue a moment to process, then print delivery status.
  setTimeout(() => {
    console.log('\n--- Delivery Log ---');
    console.log(JSON.stringify(getDeliveryLog(), null, 2));
  }, 500);
}

demo();
