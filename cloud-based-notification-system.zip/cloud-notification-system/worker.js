const { v4: uuidv4 } = require('uuid');
const queue = require('./queue');
const { recordDelivery } = require('./tracker');
const { sendEmail } = require('./channels/email');
const { sendSms } = require('./channels/sms');
const { sendPush } = require('./channels/push');

/**
 * Worker subscribes to the queue's 'message' event and routes each
 * notification to the right channel(s) — this is the equivalent of a
 * Lambda function triggered by an SQS/SNS event in a serverless deployment.
 */
queue.on('message', async (notification) => {
  const deliveryId = uuidv4();
  const { channels, recipient, subject, body } = notification;

  for (const channel of channels) {
    try {
      let result;
      if (channel === 'email') {
        result = await sendEmail({ to: recipient.email, subject, body });
      } else if (channel === 'sms') {
        result = await sendSms({ to: recipient.phone, body });
      } else if (channel === 'push') {
        result = await sendPush({ deviceToken: recipient.deviceToken, title: subject, body });
      } else {
        result = { success: false, error: `Unknown channel: ${channel}` };
      }

      recordDelivery({
        deliveryId,
        channel,
        recipient,
        subject,
        status: result.success ? 'DELIVERED' : 'FAILED',
        simulated: result.simulated ?? null,
        error: result.error ?? null,
      });
    } catch (err) {
      recordDelivery({
        deliveryId,
        channel,
        recipient,
        subject,
        status: 'FAILED',
        error: err.message,
      });
    }
  }
});

module.exports = queue;
