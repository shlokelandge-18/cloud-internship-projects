const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'data', 'delivery-log.json');

function _readLog() {
  if (!fs.existsSync(DATA_FILE)) return [];
  const raw = fs.readFileSync(DATA_FILE, 'utf-8').trim();
  return raw ? JSON.parse(raw) : [];
}

function _writeLog(entries) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(entries, null, 2));
}

/**
 * Records the outcome of a notification delivery attempt.
 * This is the equivalent of writing a delivery-status row to DynamoDB.
 */
function recordDelivery(entry) {
  const log = _readLog();
  log.push({ ...entry, timestamp: new Date().toISOString() });
  _writeLog(log);
}

function getDeliveryLog() {
  return _readLog();
}

module.exports = { recordDelivery, getDeliveryLog };
